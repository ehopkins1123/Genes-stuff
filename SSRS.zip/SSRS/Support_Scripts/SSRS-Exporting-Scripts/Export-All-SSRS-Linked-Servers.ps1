﻿function get-linkscripts {
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver
$srv.LinkedServers | foreach {
$Linkeservername = $_.Name
$_.Script()+ "GO" |  Out-File $([string]$directoryname + $Linkeservername+".sql") 


} 
}


$servers = hostname
 


$directoryname = 'D:\Support_Scripts\Exported-Items\' + "Linked-Servers" + '\' 

 if (!(Test-Path -path $directoryname))
 {
 New-Item $directoryname -type directory | Out-Null
 }
$sqlserver = $server


Try {

get-linkscripts

Write-host "Exported items are here: $directoryname"
}
Catch 
{
write-host "Error..."

}

 