﻿
#PLEASE PUT THE DRIVE NAME YOU WANT TO WRITE TO BELOW "
$rootDrive = "D:\Support_Scripts\Exported-Items\SQL-Database-Objects"
 
 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null

$MyScripter=new-object ("Microsoft.SqlServer.Management.Smo.Scripter")
$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" "localhost"

$DatabaseName = Read-Host "Type in the Database name"

$databaselist = $srv.databases.name

if ( $DatabaseName -ne $null -and $databaselist -contains $DatabaseName    )
{
Write-host "Found database $DatabaseName!"

Write-host "Collecting items"
foreach($sqlDatabase in $srv.databases)
{


if($sqlDatabase.name -eq $DatabaseName)

{
    $sqlDatabase.name 
	$procs = $sqlDatabase.StoredProcedures
	$views = $sqlDatabase.views
	$tables = $sqlDatabase.tables
	$udfs = $sqlDatabase.UserDefinedFunctions
	$sqlDatabaseName = $sqlDatabase.name
	$MyScripter.Server=$srv
 
 
	
	
	"************* $sqlDatabaseName"
	
  $procs.count
	

$DBObjects = Get-ChildItem $rootDrive\$sqlDatabaseName  -Recurse

IF($DBObjects.count -ge "1" )
 
 {
 Write-host "Removing old DB Objects from $rootDrive\$sqlDatabaseName"
    Remove-Item  $rootDrive\$sqlDatabaseName\*  -recurse
 
 }
  
  
if ( -not(test-path $rootDrive\$sqlDatabaseName) )

{

New-Item -itemtype directory -path  $rootDrive\$sqlDatabaseName  -Force

}

		
	#STORED PROCEDURES
	if($procs -ne $null)
	{
		foreach ($proc in $procs)
		{
			#Assuming that all non-system stored procs have proper naming convention and don't use prefixes like "sp_"
			#if ( $proc.Name.IndexOf("sp_") -eq -1 -and $proc.Name.IndexOf("xp_") -eq -1  -and $proc.Name.IndexOf("dt_") -eq -1)
            if ($proc.IsSystemObject -eq $false)
			{
				
				$fileName = $proc.name
				"Scripting STORED PROCEDURES $fileName"
				$scriptfile = "$rootDrive\$sqlDatabaseName\StoredProcedures\$filename.sql"
				New-Item $rootDrive -type directory -force | out-null
				New-Item $rootDrive\$sqlDatabaseName -type directory -force | out-null
				New-Item $rootDrive\$sqlDatabaseName\StoredProcedures -type directory -force | out-null

				$MyScripter.Options.FileName =  $scriptfile
				#AppendTofile has to be 'true' in order that all the procs' scripts will be appended at the end
				$MyScripter.Options.AppendToFile = "true"
				$MyScripter.Script($proc)|out-null
			}
		} 
	}
	
	




	#VIEWS
	if($views -ne $null)
	{
		foreach ($view in $views)
		{
			#Only script views that are properly named
			#if ( $view.Name.IndexOf("View") -eq 0)
	        if ( $view.IsSystemObject -eq $false)
			{

				
				$fileName = $view.name
				"Scripting View $fileName"
				$scriptfile = "$rootDrive\$sqlDatabaseName\Views\$fileName.sql"
				New-Item $rootDrive\ -type directory -force | out-null
				New-Item $rootDrive\$sqlDatabaseName -type directory -force | out-null
				New-Item $rootDrive\$sqlDatabaseName\Views -type directory -force | out-null
				$MyScripter.Options.FileName = $scriptfile
				#AppendTofile has to be 'true' in order that all the procs' scripts will be appended at the end
				$MyScripter.Options.AppendToFile = "true"
				$MyScripter.Script($view)|out-null
			}
		} 
	}
	
	
		#TABLES
	if($tables -ne $null)
	{
				 $tablearray = $Null
				# $scriptfile = "$rootDrive\$sqlDatabaseName\AllTables.sql"
				New-Item $rootDrive\ -type directory -force | out-null
				New-Item $rootDrive\$sqlDatabaseName -type directory -force | out-null
                New-Item $rootDrive\$sqlDatabaseName\Tables -type directory -force | out-null
				# $MyScripter.Options.FileName = $scriptfile
				#AppendTofile has to be 'true' in order that all the procs' scripts will be appended at the end
				# # "Scripting out creation script for all tables in $sqlDatabasename"
				## $MyScripter.Options.AppendToFile = $True
                ##  $MyScripter.Script($tables) |out-null
                # $tables.COUNT
		            foreach ($table in $tables)
		            {		
                            	
                          $tableName = $table.name
                          
                          IF ( $table.IsSystemObject -eq $false )
                            { 
                            $scriptfile = "$rootDrive\$sqlDatabaseName\Tables\$tableName.sql"
                            
                            $MyScripter.Options.FileName = $scriptfile
                            $MyScripter.Options.AppendToFile = $True
                            write-host "Scripting Table $tableName" -ForegroundColor Green
				            
                             $MyScripter.Script( $table) |out-null
                             }
                    } 
 
         

        	foreach ($table in $tables)
		{			
              $tableName = $table.name
              $tablearray+=@($table ) 
                  


				#TRIGGERS
				if($table.triggers -ne $null)
				{
					foreach ($trigger in $table.triggers)
					{
						
						$fileName = $trigger.name
						"Scripting trigger $fileName"
						$scriptfile = "$rootDrive\$sqlDatabaseName\Triggers\$fileName.sql"
						New-Item $rootDrive\ -type directory -force | out-null
						New-Item $rootDrive\$sqlDatabaseName -type directory -force | out-null
						New-Item $rootDrive\$sqlDatabaseName\Triggers -type directory -force | out-null
						$MyScripter.Options.FileName = $scriptfile
						#AppendTofile has to be 'true' in order that all the procs' scripts will be appended at the end
						$MyScripter.Options.AppendToFile = "true"
						$MyScripter.Script($trigger)|out-null
					}
				}
				
				
				
		} 
	}
	
	#USER DEFINED FUNCTIONS
	if($udfs -ne $null)
	{
		foreach ($udf in $udfs)
		{
			#if ( $udf.Name.IndexOf("dm_") -eq -1 -and $udf.Name.IndexOf("fn_") -eq -1
            if ( $udf.IsSystemObject -eq $false )
				{
					$fileName = $udf.name
					"Scripting FUNCTIONS $fileName"
					$scriptfile = "$rootDrive\$sqlDatabaseName\functions\$fileName.sql"
					New-Item $rootDrive\ -type directory -force | out-null
					New-Item $rootDrive\$sqlDatabaseName -type directory -force | out-null
					New-Item $rootDrive\$sqlDatabaseName\functions -type directory -force | out-null
					$MyScripter.Options.FileName = $scriptfile
					#AppendTofile has to be 'true' in order that all the procs' scripts will be appended at the end
					$MyScripter.Options.AppendToFile = "true"
					$MyScripter.Script($udf)|out-null
				}
		}
	} 


}


} 

 

# update Rename folder to match VSO Source Control
Rename-Item "$rootDrive\$sqlDatabaseName\StoredProcedures" "$rootDrive\$sqlDatabaseName\Stored Procedures"| Out-Null


Write-host "Exported items are here: $rootDrive\$sqlDatabaseName"

}
else

{
Write-host "Error: failed to locate database $DatabaseName "
}