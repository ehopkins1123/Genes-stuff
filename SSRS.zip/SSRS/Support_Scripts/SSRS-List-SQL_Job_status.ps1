﻿# list SQL job status 

## Load the .NET assembly.
[System.Reflection.Assembly]::LoadWithPartialName(  "Microsoft.SqlServer.Smo") | Out-Null;

$serv = hostname
  $Server=New-Object "Microsoft.SqlServer.Management.Smo.Server" $serv 
$Server.JobServer.jobs | select Name, LastRunOutcome,IsEnabled |Format-Table -AutoSize