﻿$serv = hostname

$reportServerUri = "http://$serv/reportserver/ReportService2010.asmx?wsdl"
$rs = New-WebServiceProxy -Uri $reportServerUri -UseDefaultCredential  -Namespace "SSRS"

Write-host "Collecting data....."

# List everything(!) on the Report Server, recursively
$catalogItems = $rs.ListChildren("/", $true)
 
# List all Linked Reports, together with the path of the Report it refers to.
$linkedReports = $rs.ListChildren("/", $true) |Where-Object {$_.typename -eq "DataSource"} 

 #  $linkedReports| Select name, Path, Typename,hidden |Format-Table -AutoSize
 
 

$DSreport =  foreach ($DS in  $linkedReports)
 
 { 
      $Object  = New-Object PSCustomObject
  $dataSource = $Null

 $dataSource =  $rs.GetDataSourceContents($DS.Path)

  #$rs.GetDataSourceContents('/SCSM-2012-DW')

 If( $dataSource -ne $null )#-and $dataSource.CredentialRetrieval -eq "Store")
 {
    
           # Write-Host "Report: $($report.name) "
          #  ($dataSource | Select * | Format-list)
          ## Write-Host " UserName: $($dataSource.UserName)
 

$Object | Add-Member -type NoteProperty -Name DataSourceName -Value $DS.name -Force
$Object | Add-Member -type NoteProperty -Name Path -Value $DS.Path -Force
$Object | Add-Member -type NoteProperty -Name hidden -Value $DS.hidden -Force
$Object | Add-Member -type NoteProperty -Name CredlRetrieval -Value  $dataSource.CredentialRetrieval -Force
$Object | Add-Member -type NoteProperty -Name ADAccount -Value  $dataSource.WindowsCredentials -Force
# $Object | Add-Member -type NoteProperty -Name ImpersonateUserSpecified -Value $dataSource.ImpersonateUserSpecified -Force
$Object | Add-Member -type NoteProperty -Name UserName -Value $dataSource.UserName -Force
$Object | Add-Member -type NoteProperty -Name Enabled -Value  $dataSource.Enabled -Force
$Object | Add-Member -type NoteProperty -Name ConnectString -Value  $dataSource.ConnectString -Force
 $Object
   $dataSource = $Null
 }
 
 }

 

 Try 
 {
 $DSreport|Out-GridView
 }
 Catch 
 
 {

$DSreport | Select DataSourceName,UserName,CredlRetrieval, ADAccount,Path |Format-Table -AutoSize

}
 
Write-host "Total Data Sources found: $($DSreport.count)"
