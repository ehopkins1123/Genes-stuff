﻿
      
## Load the .NET assembly.
[System.Reflection.Assembly]::LoadWithPartialName(  "Microsoft.SqlServer.Smo") | Out-Null;

        $verbosePreference="continue"  
        [datetime] $TodayDate = get-date -Format "yyyy/MM/dd hh:mm:ss" 
           
        $serv = hostname
         
        $LineNumber = 1 
        $FinalResult = @() 
       
               $Server=New-Object "Microsoft.SqlServer.Management.Smo.Server" 
               $linkedServerCount =    $Server.linkedservers.count

               Try {
               $Server.linkedservers| where-object {$_.State -eq "Existing"} | foreach { 
                
                Write-host "Count: $LineNumber out of $($linkedServerCount) "

                Write-host "Linked Server name: $($_)"

                    $Object = New-Object PSObject 
                     
                    [datetime]$DateLastModified = "{0:yyyy-MM-dd hh:mm:ss}" -f [datetime] $_.DateLastModified   
     
                    $Object | add-member Noteproperty LineNumber                      $LineNumber      
                    $Object | add-member Noteproperty Date                          $TodayDate      
                    $Object | add-member Noteproperty ServerName                      $svr 
                    $Object | add-member Noteproperty LinkedServerName                 $_.Name 
                    $Object | add-member Noteproperty DataSource                     $_.DataSource                      
                    $Object | add-member Noteproperty DateLastModified                 $DateLastModified 
                    $Object | add-member Noteproperty CollationCompatible             $_.CollationCompatible 
                    $Object | add-member Noteproperty DataAccess                     $_.DataAccess 
                    $Object | add-member Noteproperty RPC                             $_.RPC 
                    $Object | add-member Noteproperty RpcOut                         $_.RPCOut 
                    $Object | add-member Noteproperty UseRemoteCollation            $_.UseRemoteCollation 
                    $Object | add-member Noteproperty CollationName                    $_.CollationName                     
                    $Object | add-member Noteproperty ConnectionTimeOut                $_.ConnectTimeOut 
                    $Object | add-member Noteproperty QueryTimeOut                    $_.QueryTimeOut                     
                    $Object | add-member Noteproperty Distributor                     $_.Distributor                     
                    $Object | add-member Noteproperty Publisher                     $_.Publisher                     
                    $Object | add-member Noteproperty Subscriber                     $_.Subscriber                                         
                    $Object | add-member Noteproperty LazySchemaValidation             $_.LazySchemaValidation 
                    $Object | add-member Noteproperty EnablePromotionofDistributedTransactionsForRPC        $_.IsPromotionofDistributedTransactionsForRPCEnable                     
                    $Object | add-member Noteproperty ProviderName                     $_.ProviderName                     
                    $Object | add-member Noteproperty ProductName                    $_.ProductName 
                    try 
                    { 
                        $_.testconnection()  

                        $Object | add-member Noteproperty Connectivity                $True 
                        Write-Host "Test connection = True" -ForegroundColor Green
                    } catch { 

                        $Object | add-member Noteproperty Connectivity                $False 
                        Write-Host "Test connection = True" -ForegroundColor Red

                    } 
                     
                    $FinalResult += $Object 
                    $LineNumber ++  
                }  
     
             }
              catch {         
                        $msg = $error[0] 
                        Write-Warning $msg 
                        Save-SQLMsg "Get-SQLLinkedServer" "$svr" "" "$msg"  
                        continue 
            }  
             
   
         
       #  Write-Output $FinalResult  |Out-GridView
<#
# example 
 $FinalResult[0]
LineNumber                                     : 1
Date                                           : 8/31/2015 7:20:27 AM
ServerName                                     : BN1LSDSSRSDB501
LinkedServerName                               : 10.223.118.182
DataSource                                     : 10.223.118.182
DateLastModified                               : 12/16/2014 8:25:00 AM
CollationCompatible                            : False
DataAccess                                     : True
RPC                                            : False
RpcOut                                         : False
UseRemoteCollation                             : True
ProviderName                                   : SQLNCLI
ProductName                                    : SQL Server
Connectivity                                   : True
#>
 $FinalResult | Select LineNumber,Date,DateLastModified,ServerName,DataSource,ProductName ,Connectivity| Format-Table -AutoSize