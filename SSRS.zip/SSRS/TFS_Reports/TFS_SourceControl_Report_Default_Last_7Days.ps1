﻿
    function Export-CSV {
    [CmdletBinding(DefaultParameterSetName='Delimiter',
      SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    param(
     [Parameter(Mandatory=$true, ValueFromPipeline=$true,
               ValueFromPipelineByPropertyName=$true)]
     [System.Management.Automation.PSObject]
     ${InputObject},
     
     [Parameter(Mandatory=$true, Position=0)]
     [Alias('PSPath')]
     [System.String]
     ${Path},
     
     #region -Append (added by Dmitry Sotnikov)
     [Switch]
     ${Append},
     #endregion
     
     [Switch]
     ${Force},
     
     [Switch]
     ${NoClobber},
     
     [ValidateSet('Unicode','UTF7','UTF8','ASCII','UTF32','BigEndianUnicode','Default','OEM')]
     [System.String]
     ${Encoding},
     
     [Parameter(ParameterSetName='Delimiter', Position=1)]
     [ValidateNotNull()]
     [System.Char]
     ${Delimiter},
     
     [Parameter(ParameterSetName='UseCulture')]
     [Switch]
     ${UseCulture},
     
     [Alias('NTI')]
     [Switch]
     ${NoTypeInformation})
     
    begin
    {
     # This variable will tell us whether we actually need to append
     # to existing file
     $AppendMode = $false
     
     try {
      $outBuffer = $null
      if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer))
      {
          $PSBoundParameters['OutBuffer'] = 1
      }
      $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand('Export-Csv',
        [System.Management.Automation.CommandTypes]::Cmdlet)
           
           
            #String variable to become the target command line
            $scriptCmdPipeline = ''
     
            # Add new parameter handling
            #region Dmitry: Process and remove the Append parameter if it is present
            if ($Append) {
     
                    $PSBoundParameters.Remove('Append') | Out-Null
       
      if ($Path) {
       if (Test-Path $Path) {        
        # Need to construct new command line
        $AppendMode = $true
       
        if ($Encoding.Length -eq 0) {
         # ASCII is default encoding for Export-CSV
         $Encoding = 'ASCII'
        }
       
        # For Append we use ConvertTo-CSV instead of Export
        $scriptCmdPipeline += 'ConvertTo-Csv -NoTypeInformation '
       
        # Inherit other CSV convertion parameters
        if ( $UseCulture ) {
         $scriptCmdPipeline += ' -UseCulture '
        }
        if ( $Delimiter ) {
         $scriptCmdPipeline += " -Delimiter '$Delimiter' "
        }
       
        # Skip the first line (the one with the property names)
        $scriptCmdPipeline += ' | Foreach-Object {$start=$true}'
        $scriptCmdPipeline += '{if ($start) {$start=$false} else {$_}} '
       
        # Add file output
        $scriptCmdPipeline += " | Out-File -FilePath '$Path' -Encoding '$Encoding' -Append "
       
        if ($Force) {
         $scriptCmdPipeline += ' -Force'
        }
     
        if ($NoClobber) {
         $scriptCmdPipeline += ' -NoClobber'
        }  
       }
      }
     }
     
     
     
     $scriptCmd = {& $wrappedCmd @PSBoundParameters }
     
     if ( $AppendMode ) {
      # redefine command line
      $scriptCmd = $ExecutionContext.InvokeCommand.NewScriptBlock(
          $scriptCmdPipeline
        )
     } else {
      # execute Export-CSV as we got it because
      # either -Append is missing or file does not exist
      $scriptCmd = $ExecutionContext.InvokeCommand.NewScriptBlock(
          [string]$scriptCmd
        )
     }
     
     # standard pipeline initialization
     $steppablePipeline = $scriptCmd.GetSteppablePipeline($myInvocation.CommandOrigin)
     $steppablePipeline.Begin($PSCmdlet)
     
     } catch {
       throw
     }
       
    }
     
    process
    {
      try {
          $steppablePipeline.Process($_)
      } catch {
          throw
      }
    }
     
    end
    {
      try {
          $steppablePipeline.End()
      } catch {
          throw
      }
    }
    <#
     
    .ForwardHelpTargetName Export-Csv
    .ForwardHelpCategory Cmdlet
     
    #>
     
    }
 
# Loads Windows PowerShell snap-in if not already loaded
if ( (Get-PSSnapin -Name Microsoft.TeamFoundation.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PSSnapin Microsoft.TeamFoundation.PowerShell
}

# Variables - CHECK EACH TIME
[string] $tfsCollectionPath = "http://vstfxbox:8080/tfs/IEB"

# Not Used 
#[string] $locationToSearch = "$/XBox Live/Infrastructure/LSDSYS/SCOM/Main/SCOM2012/Unsealed"
#[string] $outputFile = "c:\temp\ChangesToTFS.txt"


# create paht list 
# Remove list if found.
Remove-Item  .\PathList.csv -Force -ErrorAction SilentlyContinue
  
# Create a list of Paths for SCOM and SCSM to track check ins.
$PathList = New-Object PSCustomObject
                                                  
    # SCOM _MP_Unsealed
        $PathList | Add-Member -type NoteProperty -Name Type -Value "SCOM MP" 
        $PathList | Add-Member -type NoteProperty -Name Path -Value "$/XBox Live/Infrastructure/LSDSYS/SCOM/Main/SCOM2012/Unsealed" -force
        $PathList |Export-Csv -path .\PathList.csv -Append -NoTypeInformation

    # SCOM _MP_sealed
        $PathList | Add-Member -type NoteProperty -Name Type -Value  "SCOM MP" -force
        $PathList | Add-Member -type NoteProperty -Name Path -Value  "$/XBox Live/Infrastructure/LSDSYS/SCOM/Main/SCOM2012/Sealed" -force 
        $PathList |Export-Csv -path .\PathList.csv  -Append -NoTypeInformation

    # XTC
        $PathList | Add-Member -type NoteProperty -Name Type -Value  "XTC" -force
        $PathList | Add-Member -type NoteProperty -Name Path -Value  "$/XBox Live/Infrastructure/LSDSYS/SCOM/Main/SCOM2012/XTCSpreadsheets" -force 
        $PathList |Export-Csv -path .\PathList.csv  -Append -NoTypeInformation

    # SCSM 
        # SCSM _Dev_Unsealed
            $PathList | Add-Member -type NoteProperty -Name Type -Value  "SCSM MP" -force
            $PathList | Add-Member -type NoteProperty -Name Path -Value  "$/XBox Live/Infrastructure/LSDSYS/SCSM/ManagementPacks/Dev/Unsealed" -force 
            $PathList |Export-Csv -path .\PathList.csv  -Append -NoTypeInformation
        # SCSM _Int_Unsealed
            $PathList | Add-Member -type NoteProperty -Name Type -Value  "SCSM MP" -force
            $PathList | Add-Member -type NoteProperty -Name Path -Value  "$/XBox Live/Infrastructure/LSDSYS/SCSM/ManagementPacks/Int/Unsealed" -force 
            $PathList |Export-Csv -path .\PathList.csv  -Append -NoTypeInformation
                        
        # SCSM _Prod_Unsealed
            $PathList | Add-Member -type NoteProperty -Name Type -Value  "SCSM MP" -force
            $PathList | Add-Member -type NoteProperty -Name Path -Value  "$/XBox Live/Infrastructure/LSDSYS/SCSM/ManagementPacks/Prod/Unsealed" -force 
            $PathList |Export-Csv -path .\PathList.csv  -Append -NoTypeInformation

        # SCMS _MP_Prod_Sealed
            $PathList | Add-Member -type NoteProperty -Name Type -Value  "SCSM MP" -force
            $PathList | Add-Member -type NoteProperty -Name Path -Value  "$/XBox Live/Infrastructure/LSDSYS/SCSM/ManagementPacks/Prod/Sealed" -force 
            $PathList |Export-Csv -path .\PathList.csv  -Append -NoTypeInformation                  

                
# Set deate Ragne: 


if ( $args -ne $NULL )
{
# set date range by -Number

[string]$Days = $args

Write-host "Default date rang is today $($args) days."
 
Write-host  "Set day to $($Days)" -BackgroundColor white -ForegroundColor Black

}

# default value is today -7 days.
Else 
{

# set date range by -Number
$todayDate =  (Get-date).ToShortDateString()

$Days = "-7" 
Write-host  "Set day to $($Days)" -BackgroundColor white -ForegroundColor Black
$Xtoday = (get-date).AddDays($days)


Write-host " default date Range is today $todayDate 'minus' $($Xtoday.ToShortDateString())"


}

 
 $TODAY = (Get-DATE).AddDays($Days)
 $Year = $TODAY.Year
 $Month = $Today.Month
 # Add A "0" to month if less then 10
 IF ($Month -le 10)
 {
 $Month = "0" +$Month 
 }

 $day =  $Today.day

 # Add A "0" to day if less then 10
  IF ( $day -le 10 )
 {
  $day = "0" +  $day
 }

 $day =  $Today.day

 $Value_year =  "D" + $Year 
 $Value_Month =  $Month
 $Value_day = $day 

[string] $dateRange = $Value_year + "-" + $Value_Month  + "-" + $Value_day +  " 00:00:00Z~"
 

# For a date/time range: 'D2012-08-06 00:00:00Z~D2012-08-09 23:59:59Z'
# For everything including and after a date/time: 'D2012-07-21 00:00:00Z~'


#
# not used
#[bool] $openOutputFile = $true # Accepts $false or $true
#



[Microsoft.TeamFoundation.Client.TfsTeamProjectCollection] $tfs = get-tfsserver $tfsCollectionPath

<#  Not used 
# Add informational header to file manifest
[string] $outputHeader =
    "Team Collection: " + $tfsCollectionPath + "`r`n" +
    "Source Location: " + $locationToSearch + "`r`n" +
    "Date Range: " + $dateRange + "`r`n" +
    "Created: " + (Get-Date).ToString() + "`r`n" +
    "======================================================================"

$outputHeader | Out-File $outputFile
#>
  
Remove-Item report.csv -Force -ErrorAction SilentlyContinue

$item  = $Null
$Results = New-Object PSCustomObject

 
  function Get-data 
 {
 Write-host "SerachPath: $($args[0])"
  Write-host "type: $($args[1])"

 $SerachPath = $args[0] 
 $type = $args[1]
 


 $ItemHostry = $Null
 $Get_ItemHistory = $null

  # Get data 
  #   $Get_Items = Get-TfsItemProperty $SerachPath -Recurse   -Server $tfs|where {$_.CheckinDate -gt (get-date).AddDays($Days) }    
  
  $Get_Items = Get-TfsItemProperty $SerachPath -Recurse |where {$_.CheckinDate -gt (get-date).AddDays($Days) }    
  
 # $Get_Items |Select TargetServerItem,LockStatus, LockOwner, CheckinDate| Format-Table -AutoSize


 foreach ($item in  $Get_Items )
 {
 
  $matches = $Null
  
  Write-host "Working on $($item)" 
  Write-host "Check in Date $($item.CheckinDate)" -ForegroundColor White -BackgroundColor Black
  

    ### Get file Name

    $re1='.*?';	# Non-greedy match on filler
    $re2='((?:[a-z][a-z\.\d_]+)\.(?:[a-z\d]{3}))(?![\w\\.])';	# File Name 1

    $rex=$re1+$re2;

    $item.TargetServerItem -match $rex
 
   # get file name
    $fileName = $matches[1]
  
   # $item.SourceServerItem

    $fileData = Get-TfsItemHistory $item.SourceServerItem  -Version  $dateRange -Server $tfs   -IncludeItems | where {$_.changes -like "*edit*"}
 

    IF ( $fileData.Count -gt 1 )
       
       {

        foreach ($i in $fileData ) 
        
        {

         #Results
        $Results | Add-Member -type NoteProperty -Name File -Value   $fileName -force
        $Results | Add-Member -type NoteProperty -Name Type -Value    $type -force

        $Results | Add-Member -type NoteProperty -Name Owner -Value  $i.Owner -force
        $Results | Add-Member -type NoteProperty -Name Changesetid -Value $i.Changesetid  -force 
        $Results | Add-Member -type NoteProperty -Name CreationDate -Value  $i.CreationDate  -force
        $Results | Add-Member -type NoteProperty -Name Comment -Value  $i.Comment  -force

        $Results |Export-Csv -path .\report.csv -Append 
    
        }                 
    
      }

     else {

        #Results
    $Results | Add-Member -type NoteProperty -Name File -Value   $fileName -force
    $Results | Add-Member -type NoteProperty -Name Type -Value    $type -force
    $Results | Add-Member -type NoteProperty -Name Owner -Value  $fileData.Owner -force
    $Results | Add-Member -type NoteProperty -Name Changesetid -Value $fileData.Changesetid  -force 
    $Results | Add-Member -type NoteProperty -Name CreationDate -Value  $fileData.CreationDate  -force
    $Results | Add-Member -type NoteProperty -Name Comment -Value  $fileData.Comment  -force
  

    $Results |Export-Csv -path .\report.csv -Append 
    
            }
  }
    
  




 }

$paths =  import-csv -Path .\PathList.csv

Foreach ($Path in $paths)
{


 
 
 Get-data $Path.path $Path.Type
 
 }  

  $data =  import-csv -path .\report.csv 

 
 Import-Csv -Path .\Report.csv  | Out-GridView

 Remove-Item TFS_SourceControl_Item_Report.csv -Force -ErrorAction SilentlyContinue
 $data | Group-Object Type |Select-Object Name, Count | Select @{Expression={$_.Name};Label="Type"},@{Expression={$_.Count};Label="Updated files"}  |Sort-Object Type |    Export-csv -path TFS_SourceControl_Item_Report.csv -NoTypeInformation
  
 Import-Csv -Path .\TFS_SourceControl_Item_Report.csv |Out-GridView