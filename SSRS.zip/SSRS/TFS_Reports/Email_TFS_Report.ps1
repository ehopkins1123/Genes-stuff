$SMTPserver = "QxInfScsmXMS602.redmond.corp.microsoft.com"
$Attachment1 = "C:\Temp\TFS_SourceControl_Last_7Ddays_Item_Report.csv"
$Attachment2 = "C:\Temp\TFS_SourceControl_Report.csv"

$titel = "Infrastructure - Monitoring Files Updated In The Past Seven Days" 

$TEXT = Import-csv -path 'c:\Temp\TFS_SourceControl_Report.csv' | ConvertTo-Html  -body $titel 

[string]$TEXT =  $TEXT

send-mailmessage -SmtpServer $SMTPserver -from "xocsmwrk@microsoft.com" -to "v-jobudi@microsoft.com" -cc "v-micor@microsoft.com", "mrepper@microsoft.com", "v-eugenh@microsoft.com"  -subject $titel -BodyAsHtml -body  $TEXT  -Attachments $Attachment1,$Attachment2  ;
